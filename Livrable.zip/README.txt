Comme expliquer en classe le 21/10/2021

Vous trouverez dans le dossier le fichier projet pour pouvoir compiler le source avec la commande msbuild.

procédure:
1: ouvrir le Visual Studio Developer Command Prompt.
2: accéder au dossier du livrable
3: tapper la commande (msbuild ProjetEpitaSDL.vcxproj /p:Configuration=Release)
4: vous pouvez lancer l'exe qui ce trouve dans le dossier Release


/!\
le troisieme argument du programme correspond au temps en SECONDE. 